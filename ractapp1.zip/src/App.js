import React from 'react'
import Bundle from './components/Bundle'
import './App.css';
export default function App() {
  return (
    <>
    <Bundle/>
    </>
  )
}

